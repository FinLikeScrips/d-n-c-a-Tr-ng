#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <WiFi.h>

#define REAL_HARDWARE_MODE 0

#define WORKER_HOST    "mybot.phamquangtruong777.workers.dev"
#define WORKER_ESP_URL "https://mybot.phamquangtruong777.workers.dev/api/esp"
#define SIM_WIFI_SSID  "Wokwi-GUEST"
#define SIM_WIFI_PASS  ""

#if REAL_HARDWARE_MODE == 0
  #include <HTTPClient.h>
#else
  #include <WebServer.h>
  #include <DNSServer.h>
  #include <Preferences.h>
  #include <WebSocketsClient.h>
  #include <math.h>
  #if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
    #include <driver/i2s_std.h>
    #define USE_I2S_V3 1
  #else
    #include <driver/i2s.h>
    #define USE_I2S_V3 0
  #endif
#endif

#define OLED_SCL_PIN     0
#define OLED_SDA_PIN     1
#define LED_STATUS_PIN   8
#define BTN_PTT_PIN      9

#if REAL_HARDWARE_MODE == 0
  #define BTN_PWR_PIN      3
  #define MIC_ANALOG_PIN   4
  #define BTN_VOICE_PIN    5
  #define SW_MAIN_PWR_PIN  6
  #define SPEAKER_PIN      10
#else
  #define I2S_BCLK_PIN     4
  #define I2S_WS_PIN       5
  #define I2S_MIC_SD_PIN   6
  #define I2S_SPK_DIN_PIN  7
#endif

#define SCREEN_WIDTH     128
#define SCREEN_HEIGHT    64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

enum BotState {
  STATE_POWER_OFF,
  STATE_BOOT,
  STATE_IDLE,
  STATE_LISTENING,
  STATE_THINKING,
  STATE_SPEAKING,
  STATE_MUSIC,
  STATE_STORY,
  STATE_SLEEPING
};

BotState currentState = STATE_BOOT;
bool oledReady = false;
bool wifiOnline = false;

String subtitleText = "San sang! Giu GPIO9";
int audioLevel = 0;
int eyeOffsetX = 0;
int targetEyeX = 0;
bool isBlinking = false;
unsigned long nextBlinkTime = 2400;
unsigned long nextSaccadeTime = 1600;
unsigned long lastFrameTime = 0;

bool pomoActive = false;
bool pomoIsBreak = false;
unsigned long pomoEndMs = 0;
uint16_t pomoBreakMin = 5;
String pomoLabel = "Hoc tap";

unsigned long storySleepEndMs = 0;

struct MemEntry {
  String text;
  unsigned long expMs;
};
const size_t MEM_MAX = 6;
const unsigned long MEM_TTL_MS = 15UL * 60UL * 1000UL;
MemEntry tempMem[MEM_MAX];
size_t tempMemCount = 0;

bool isHoldingPTT = false;
unsigned long pttStartTime = 0;

void pruneMemory() {
  unsigned long now = millis();
  size_t w = 0;
  for (size_t i = 0; i < tempMemCount; i++) {
    if ((long)(tempMem[i].expMs - now) > 0 && tempMem[i].text.length() > 0) {
      if (w != i) tempMem[w] = tempMem[i];
      w++;
    }
  }
  tempMemCount = w;
}

void pushTempMemory(const String& note) {
  pruneMemory();
  String clean = note;
  clean.trim();
  if (clean.length() == 0) return;
  if (clean.length() > 80) clean = clean.substring(0, 80);
  for (size_t i = 0; i < tempMemCount; i++) {
    if (tempMem[i].text == clean) {
      tempMem[i].expMs = millis() + MEM_TTL_MS;
      return;
    }
  }
  if (tempMemCount >= MEM_MAX) {
    for (size_t i = 1; i < MEM_MAX; i++) tempMem[i - 1] = tempMem[i];
    tempMemCount = MEM_MAX - 1;
  }
  tempMem[tempMemCount].text = clean;
  tempMem[tempMemCount].expMs = millis() + MEM_TTL_MS;
  tempMemCount++;
  Serial.print("[Nho tam]: ");
  Serial.println(clean);
}

void clearTempMemory() {
  tempMemCount = 0;
  Serial.println("[Nho tam]: Da xoa toan bo.");
}

String toSafeAscii(const String& in) {
  String out;
  out.reserve(in.length());
  for (size_t i = 0; i < in.length(); i++) {
    uint8_t c = (uint8_t)in[i];
    if (c >= 32 && c <= 126) {
      out += (char)c;
    } else if (c == '\r' || c == '\n' || c == '\t') {
      out += ' ';
    }
  }
  out.trim();
  return out;
}

void setSubtitle(const String& text) {
  String clean = toSafeAscii(text);
  if (clean.length() == 0) clean = "San sang";
  if (clean.length() > 84) clean = clean.substring(0, 84);
  subtitleText = clean;
}

#if REAL_HARDWARE_MODE == 0

struct NoteStep {
  uint16_t freq;
  uint16_t durMs;
};

const NoteStep MELODY_CHILL[] = {
  {440, 360}, {523, 360}, {494, 420}, {392, 460},
  {349, 360}, {440, 360}, {392, 420}, {330, 560},
  {294, 360}, {349, 360}, {330, 420}, {262, 500},
  {330, 380}, {294, 380}, {220, 650}, {0, 250}
};

const NoteStep MELODY_UPBEAT[] = {
  {523, 170}, {659, 170}, {784, 170}, {1046, 300},
  {784, 170}, {1046, 320}, {0, 120},
  {587, 170}, {698, 170}, {880, 170}, {1175, 300},
  {880, 170}, {1046, 340}, {0, 180}
};

const NoteStep MELODY_STORY[] = {
  {330, 460}, {392, 460}, {440, 620}, {0, 220},
  {392, 460}, {330, 460}, {294, 650}, {0, 300}
};

const NoteStep* activeMelody = NULL;
size_t activeMelodyLen = 0;
size_t activeMelodyIdx = 0;
bool activeMelodyLoop = false;
unsigned long noteEndTime = 0;

unsigned long speechEndTime = 0;
unsigned long nextSyllableTime = 0;
BotState postSpeechState = STATE_IDLE;

bool lastPwrDown = false;
unsigned long lastPwrEdgeMs = 0;
bool lastVoiceDown = false;
unsigned long lastVoiceEdgeMs = 0;
uint8_t demoCycleIndex = 0;

void playBeep(uint16_t freq, uint16_t durMs) {
  tone(SPEAKER_PIN, freq, durMs);
}

void playChime() {
  const uint16_t notes[3] = {880, 1109, 1319};
  for (int i = 0; i < 3; i++) {
    tone(SPEAKER_PIN, notes[i], 180);
    delay(210);
  }
  noTone(SPEAKER_PIN);
}

void stopMediaOnly() {
  noTone(SPEAKER_PIN);
  activeMelody = NULL;
  activeMelodyLen = 0;
  activeMelodyIdx = 0;
  speechEndTime = 0;
  postSpeechState = STATE_IDLE;
  storySleepEndMs = 0;
  audioLevel = 0;
}

void startMelody(const NoteStep* notes, size_t count, bool loopPlay) {
  activeMelody = notes;
  activeMelodyLen = count;
  activeMelodyIdx = 0;
  activeMelodyLoop = loopPlay;
  noteEndTime = 0;
}

String urlEncode(const String& s) {
  static const char hex[] = "0123456789ABCDEF";
  String out;
  out.reserve(s.length() * 3);
  for (size_t i = 0; i < s.length(); i++) {
    uint8_t c = (uint8_t)s[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.' || c == '~') {
      out += (char)c;
    } else if (c == ' ') {
      out += "%20";
    } else {
      out += '%';
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }
  return out;
}

String getFieldLine(const String& payload, const char* prefix) {
  String p = String(prefix);
  int start = payload.indexOf(p);
  if (start < 0) return "";
  start += p.length();
  int end = payload.indexOf('\n', start);
  String val = (end < 0) ? payload.substring(start) : payload.substring(start, end);
  val.trim();
  return val;
}

#else

enum I2SMode {
  I2S_MODE_NONE,
  I2S_MODE_MIC,
  I2S_MODE_SPK
};

I2SMode activeI2SMode = I2S_MODE_NONE;
#if USE_I2S_V3
  i2s_chan_handle_t rxHandle = NULL;
  i2s_chan_handle_t txHandle = NULL;
#endif

Preferences prefs;
WebServer portalServer(80);
DNSServer dnsServer;
WebSocketsClient webSocket;

bool portalActive = false;
bool wsConnected = false;
unsigned long lastBotAudioMs = 0;
int32_t micRaw32[256];
int16_t micPcm16[256];
int16_t silencePcm[256];

void stopI2S() {
#if USE_I2S_V3
  if (rxHandle != NULL) {
    i2s_channel_disable(rxHandle);
    i2s_del_channel(rxHandle);
    rxHandle = NULL;
  }
  if (txHandle != NULL) {
    i2s_channel_disable(txHandle);
    i2s_del_channel(txHandle);
    txHandle = NULL;
  }
#else
  if (activeI2SMode != I2S_MODE_NONE) {
    i2s_driver_uninstall(I2S_NUM_0);
  }
#endif
  activeI2SMode = I2S_MODE_NONE;
}

bool switchI2SMode(I2SMode target) {
  if (activeI2SMode == target) return true;
  stopI2S();
  if (target == I2S_MODE_NONE) return true;

#if USE_I2S_V3
  i2s_chan_config_t chanCfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
  chanCfg.auto_clear = true;
  if (target == I2S_MODE_MIC) {
    if (i2s_new_channel(&chanCfg, NULL, &rxHandle) != ESP_OK) return false;
    i2s_std_config_t rxCfg;
    rxCfg.clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(16000);
    rxCfg.slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT, I2S_SLOT_MODE_MONO);
    rxCfg.slot_cfg.slot_mask = I2S_STD_SLOT_LEFT;
    rxCfg.gpio_cfg.mclk = I2S_GPIO_UNUSED;
    rxCfg.gpio_cfg.bclk = (gpio_num_t)I2S_BCLK_PIN;
    rxCfg.gpio_cfg.ws = (gpio_num_t)I2S_WS_PIN;
    rxCfg.gpio_cfg.dout = I2S_GPIO_UNUSED;
    rxCfg.gpio_cfg.din = (gpio_num_t)I2S_MIC_SD_PIN;
    rxCfg.gpio_cfg.invert_flags.mclk_inv = false;
    rxCfg.gpio_cfg.invert_flags.bclk_inv = false;
    rxCfg.gpio_cfg.invert_flags.ws_inv = false;
    if (i2s_channel_init_std_mode(rxHandle, &rxCfg) != ESP_OK) {
      stopI2S();
      return false;
    }
    i2s_channel_enable(rxHandle);
  } else {
    if (i2s_new_channel(&chanCfg, &txHandle, NULL) != ESP_OK) return false;
    i2s_std_config_t txCfg;
    txCfg.clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(24000);
    txCfg.slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_MONO);
    txCfg.slot_cfg.slot_mask = I2S_STD_SLOT_LEFT;
    txCfg.gpio_cfg.mclk = I2S_GPIO_UNUSED;
    txCfg.gpio_cfg.bclk = (gpio_num_t)I2S_BCLK_PIN;
    txCfg.gpio_cfg.ws = (gpio_num_t)I2S_WS_PIN;
    txCfg.gpio_cfg.dout = (gpio_num_t)I2S_SPK_DIN_PIN;
    txCfg.gpio_cfg.din = I2S_GPIO_UNUSED;
    txCfg.gpio_cfg.invert_flags.mclk_inv = false;
    txCfg.gpio_cfg.invert_flags.bclk_inv = false;
    txCfg.gpio_cfg.invert_flags.ws_inv = false;
    if (i2s_channel_init_std_mode(txHandle, &txCfg) != ESP_OK) {
      stopI2S();
      return false;
    }
    i2s_channel_enable(txHandle);
  }
#else
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | (target == I2S_MODE_MIC ? I2S_MODE_RX : I2S_MODE_TX));
  cfg.sample_rate = (target == I2S_MODE_MIC) ? 16000 : 24000;
  cfg.bits_per_sample = (target == I2S_MODE_MIC) ? I2S_BITS_PER_SAMPLE_32BIT : I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 6;
  cfg.dma_buf_len = 256;
  cfg.use_apll = false;
  cfg.tx_desc_auto_clear = true;
  cfg.fixed_mclk = 0;

  i2s_pin_config_t pins = {};
  pins.bck_io_num = I2S_BCLK_PIN;
  pins.ws_io_num = I2S_WS_PIN;
  pins.data_out_num = (target == I2S_MODE_SPK) ? I2S_SPK_DIN_PIN : I2S_PIN_NO_CHANGE;
  pins.data_in_num = (target == I2S_MODE_MIC) ? I2S_MIC_SD_PIN : I2S_PIN_NO_CHANGE;

  if (i2s_driver_install(I2S_NUM_0, &cfg, 0, NULL) != ESP_OK) return false;
  if (i2s_set_pin(I2S_NUM_0, &pins) != ESP_OK) {
    i2s_driver_uninstall(I2S_NUM_0);
    return false;
  }
  i2s_zero_dma_buffer(I2S_NUM_0);
#endif

  activeI2SMode = target;
  return true;
}

void i2sWriteAudio(const uint8_t* data, size_t len) {
  if (!data || len < 2) return;
  if (!switchI2SMode(I2S_MODE_SPK)) return;
  size_t written = 0;
#if USE_I2S_V3
  if (txHandle != NULL) {
    i2s_channel_write(txHandle, data, len, &written, pdMS_TO_TICKS(100));
  }
#else
  i2s_write(I2S_NUM_0, data, len, &written, pdMS_TO_TICKS(100));
#endif
}

void playI2STone(uint16_t freq, uint16_t durMs) {
  if (!switchI2SMode(I2S_MODE_SPK)) return;
  const int sr = 24000;
  int totalSamples = (sr * (int)durMs) / 1000;
  int16_t buf[240];
  int produced = 0;
  while (produced < totalSamples) {
    int n = min(240, totalSamples - produced);
    for (int i = 0; i < n; i++) {
      float t = (float)(produced + i) / (float)sr;
      buf[i] = (int16_t)(5500.0f * sinf(6.2831853f * (float)freq * t));
    }
    i2sWriteAudio((const uint8_t*)buf, n * sizeof(int16_t));
    produced += n;
  }
}

void playBeep(uint16_t freq, uint16_t durMs) {
  playI2STone(freq, durMs);
}

void playChime() {
  playI2STone(880, 160);
  delay(40);
  playI2STone(1109, 160);
  delay(40);
  playI2STone(1319, 220);
}

void stopMediaOnly() {
  storySleepEndMs = 0;
  audioLevel = 0;
  if (activeI2SMode == I2S_MODE_SPK) {
    i2sWriteAudio((const uint8_t*)silencePcm, sizeof(silencePcm));
  }
}

String extractJsonStr(const String& json, const char* key) {
  String pat = String("\"") + key + "\":\"";
  int p = json.indexOf(pat);
  if (p < 0) return "";
  p += pat.length();
  String out;
  while (p < (int)json.length()) {
    char c = json[p++];
    if (c == '\\' && p < (int)json.length()) {
      out += json[p++];
      continue;
    }
    if (c == '"') break;
    out += c;
  }
  return out;
}

int extractJsonInt(const String& json, const char* key, int fallback) {
  String pat = String("\"") + key + "\":";
  int p = json.indexOf(pat);
  if (p < 0) return fallback;
  p += pat.length();
  while (p < (int)json.length() && json[p] == ' ') p++;
  int end = p;
  if (end < (int)json.length() && json[end] == '-') end++;
  while (end < (int)json.length() && isDigit(json[end])) end++;
  if (end == p) return fallback;
  return json.substring(p, end).toInt();
}

#endif

void startPomodoro(uint16_t workMin, uint16_t breakMin, const String& label) {
  if (workMin < 1) workMin = 1;
  if (workMin > 180) workMin = 180;
  if (breakMin > 60) breakMin = 60;
  pomoActive = true;
  pomoIsBreak = false;
  pomoBreakMin = breakMin;
  pomoLabel = toSafeAscii(label);
  if (pomoLabel.length() == 0) pomoLabel = "Hoc tap";
  pomoEndMs = millis() + (unsigned long)workMin * 60000UL;
  Serial.printf("[Pomodoro]: Bat dau (%s) %up / nghi %up\n", pomoLabel.c_str(), workMin, breakMin);
}

void stopPomodoro(bool silent) {
  pomoActive = false;
  pomoIsBreak = false;
  if (!silent) {
    Serial.println("[Pomodoro]: Da tat dong ho.");
  }
}

void updatePomodoro() {
  if (!pomoActive) return;
  unsigned long now = millis();
  if ((long)(pomoEndMs - now) > 0) return;

  playChime();
  if (!pomoIsBreak && pomoBreakMin > 0) {
    pomoIsBreak = true;
    pomoEndMs = now + (unsigned long)pomoBreakMin * 60000UL;
    setSubtitle("Nghi giai lao " + String(pomoBreakMin) + " phut!");
    Serial.printf("[Pomodoro]: Het gio hoc! Nghi giai lao %u phut.\n", pomoBreakMin);
  } else {
    String doneLbl = pomoLabel;
    stopPomodoro(true);
    setSubtitle("Xong Pomodoro: " + doneLbl);
    Serial.println("[Pomodoro]: Hoan thanh phien hoc!");
  }
}

void updateStorySleepTimer() {
  if (storySleepEndMs == 0) return;
  if ((long)(storySleepEndMs - millis()) <= 0) {
    stopMediaOnly();
    currentState = STATE_IDLE;
    setSubtitle("Het hen gio tat truyen");
    Serial.println("[Hen gio]: Da tu dong tat truyen.");
  }
}

void drawCuteFace() {
  if (!oledReady) return;
  display.clearDisplay();
  unsigned long now = millis();

  if (currentState == STATE_POWER_OFF) {
    display.display();
    return;
  }

  if (currentState == STATE_SLEEPING) {
    display.fillRoundRect(22, 24, 30, 4, 2, SSD1306_WHITE);
    display.fillRoundRect(76, 24, 30, 4, 2, SSD1306_WHITE);
    display.drawCircle(64, 40, 3, SSD1306_WHITE);
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(96, 6);
    display.print("Zzz");
    display.setCursor(10, 54);
    display.print("Bam nut DO de thuc");
    display.display();
    return;
  }

  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  if (pomoActive) {
    long leftMs = (long)(pomoEndMs - now);
    unsigned long leftSec = leftMs > 0 ? (unsigned long)(leftMs + 999) / 1000UL : 0;
    unsigned long mm = leftSec / 60UL;
    unsigned long ss = leftSec % 60UL;
    char buf[16];
    snprintf(buf, sizeof(buf), "%c %02lu:%02lu", pomoIsBreak ? 'R' : 'P', mm, ss);
    display.setCursor(2, 0);
    display.print(buf);
  } else if (currentState == STATE_MUSIC || currentState == STATE_STORY) {
    int ny = ((now / 260) % 3);
    display.fillCircle(4, ny + 5, 2, SSD1306_WHITE);
    display.drawLine(6, ny + 5, 6, ny, SSD1306_WHITE);
    display.drawLine(6, ny, 10, ny + 2, SSD1306_WHITE);
  }

  display.setCursor(112, 0);
  display.print(wifiOnline ? "WF" : "OF");

  if (now > nextBlinkTime && !isBlinking) {
    isBlinking = true;
    nextBlinkTime = now + 120;
  } else if (now > nextBlinkTime && isBlinking) {
    isBlinking = false;
    nextBlinkTime = now + random(2400, 4800);
  }

  if ((currentState == STATE_IDLE || currentState == STATE_MUSIC) && now > nextSaccadeTime) {
    int r = random(0, 5);
    targetEyeX = (r == 0) ? -6 : (r == 1 ? 6 : 0);
    nextSaccadeTime = now + random(1500, 3200);
  } else if (currentState != STATE_IDLE && currentState != STATE_MUSIC) {
    targetEyeX = 0;
  }
  eyeOffsetX += (targetEyeX - eyeOffsetX) / 2;

  int leftX = 22 + eyeOffsetX;
  int rightX = 76 + eyeOffsetX;
  int eyeY = 10;

  if (isBlinking) {
    display.fillRoundRect(leftX, eyeY + 9, 30, 4, 2, SSD1306_WHITE);
    display.fillRoundRect(rightX, eyeY + 9, 30, 4, 2, SSD1306_WHITE);
  } else if (currentState == STATE_SPEAKING || currentState == STATE_MUSIC) {
    display.fillRoundRect(leftX, eyeY + 2, 30, 17, 8, SSD1306_WHITE);
    display.fillRoundRect(leftX + 4, eyeY + 9, 22, 13, 6, SSD1306_BLACK);
    display.fillRoundRect(rightX, eyeY + 2, 30, 17, 8, SSD1306_WHITE);
    display.fillRoundRect(rightX + 4, eyeY + 9, 22, 13, 6, SSD1306_BLACK);
  } else if (currentState == STATE_LISTENING) {
    display.fillRoundRect(leftX - 2, eyeY, 34, 22, 8, SSD1306_WHITE);
    display.fillRoundRect(rightX - 2, eyeY, 34, 22, 8, SSD1306_WHITE);
    display.fillCircle(leftX + 10, eyeY + 7, 4, SSD1306_BLACK);
    display.fillCircle(rightX + 10, eyeY + 7, 4, SSD1306_BLACK);
    display.drawLine(6, 35, 12, 31, SSD1306_WHITE);
    display.drawLine(11, 36, 17, 32, SSD1306_WHITE);
    display.drawLine(111, 32, 117, 36, SSD1306_WHITE);
    display.drawLine(116, 31, 122, 35, SSD1306_WHITE);
  } else if (currentState == STATE_THINKING) {
    display.fillRoundRect(leftX, eyeY + 1, 30, 20, 7, SSD1306_WHITE);
    display.fillRoundRect(rightX, eyeY + 1, 30, 20, 7, SSD1306_WHITE);
    display.fillCircle(leftX + 19, eyeY + 6, 3, SSD1306_BLACK);
    display.fillCircle(rightX + 19, eyeY + 6, 3, SSD1306_BLACK);
  } else {
    display.fillRoundRect(leftX, eyeY, 30, 21, 7, SSD1306_WHITE);
    display.fillRoundRect(rightX, eyeY, 30, 21, 7, SSD1306_WHITE);
    display.fillCircle(leftX + 9, eyeY + 6, 4, SSD1306_BLACK);
    display.fillCircle(rightX + 9, eyeY + 6, 4, SSD1306_BLACK);
    display.fillCircle(leftX + 20, eyeY + 14, 2, SSD1306_BLACK);
    display.fillCircle(rightX + 20, eyeY + 14, 2, SSD1306_BLACK);
  }

  if (currentState == STATE_LISTENING) {
    int barH = map(constrain(audioLevel, 5, 100), 5, 100, 3, 12);
    for (int i = -3; i <= 3; i++) {
      int h = max(2, barH - abs(i) * 2);
      display.fillRoundRect(62 + i * 7, 41 - h / 2, 4, h, 2, SSD1306_WHITE);
    }
  } else if (currentState == STATE_SPEAKING) {
    int mouthH = map(constrain(audioLevel, 0, 100), 0, 100, 3, 11);
    int mouthW = map(constrain(audioLevel, 0, 100), 0, 100, 12, 24);
    display.fillRoundRect(64 - mouthW / 2, 36, mouthW, mouthH, mouthH / 2, SSD1306_WHITE);
  } else if (currentState == STATE_MUSIC || currentState == STATE_STORY) {
    for (int i = -2; i <= 2; i++) {
      int h = random(3, 11);
      display.fillRect(62 + i * 8, 46 - h, 5, h, SSD1306_WHITE);
    }
  } else if (currentState == STATE_THINKING) {
    int phase = (now / 180) % 3;
    for (int i = 0; i < 3; i++) {
      display.fillCircle(54 + i * 10, (i == phase) ? 39 : 43, 2, SSD1306_WHITE);
    }
  } else {
    display.drawLine(58, 40, 62, 43, SSD1306_WHITE);
    display.drawLine(62, 43, 66, 43, SSD1306_WHITE);
    display.drawLine(66, 43, 70, 40, SSD1306_WHITE);
  }

  display.drawLine(0, 51, 127, 51, SSD1306_WHITE);
  display.setCursor(2, 55);
  const size_t maxChars = 21;
  if (subtitleText.length() > maxChars) {
    String padded = subtitleText + "   ";
    size_t offset = (now / 210) % padded.length();
    String line;
    line.reserve(maxChars);
    for (size_t i = 0; i < maxChars; i++) {
      line += padded[(offset + i) % padded.length()];
    }
    display.print(line);
  } else {
    display.print(subtitleText);
  }

  display.display();
}

#if REAL_HARDWARE_MODE == 0

void updateSimAudioEngine() {
  unsigned long now = millis();

  if (currentState == STATE_SPEAKING) {
    if ((long)(speechEndTime - now) <= 0) {
      noTone(SPEAKER_PIN);
      audioLevel = 0;
      digitalWrite(LED_STATUS_PIN, HIGH);
      if (postSpeechState == STATE_MUSIC) {
        currentState = STATE_MUSIC;
      } else if (postSpeechState == STATE_STORY) {
        currentState = STATE_STORY;
      } else {
        currentState = STATE_IDLE;
      }
      return;
    }

    if ((long)(nextSyllableTime - now) <= 0) {
      int f = random(420, 960);
      int dur = random(55, 110);
      tone(SPEAKER_PIN, f, dur);
      audioLevel = random(30, 100);
      digitalWrite(LED_STATUS_PIN, !digitalRead(LED_STATUS_PIN));
      nextSyllableTime = now + dur + random(25, 55);
    }
    return;
  }

  if ((currentState == STATE_MUSIC || currentState == STATE_STORY) && activeMelody != NULL) {
    if ((long)(noteEndTime - now) <= 0) {
      if (activeMelodyIdx >= activeMelodyLen) {
        if (activeMelodyLoop) {
          activeMelodyIdx = 0;
        } else {
          stopMediaOnly();
          currentState = STATE_IDLE;
          setSubtitle("Da phat xong!");
          return;
        }
      }

      uint16_t f = activeMelody[activeMelodyIdx].freq;
      uint16_t d = activeMelody[activeMelodyIdx].durMs;
      activeMelodyIdx++;

      if (f > 0) {
        tone(SPEAKER_PIN, f, d > 30 ? d - 30 : d);
        audioLevel = map(constrain((int)f, 220, 1100), 220, 1100, 25, 95);
        digitalWrite(LED_STATUS_PIN, HIGH);
      } else {
        noTone(SPEAKER_PIN);
        audioLevel = 10;
        digitalWrite(LED_STATUS_PIN, LOW);
      }
      noteEndTime = now + d;
    }
  }
}

void applyBotResult(const String& state, const String& oled, const String& reply, int workMin, int breakMin, int sleepMin, const String& stopTarget) {
  Serial.print("[Bot AI]: ");
  Serial.println(reply);

  if (stopTarget == "all") {
    stopMediaOnly();
    stopPomodoro(false);
    currentState = STATE_IDLE;
    setSubtitle(oled.length() ? oled : "Da dung tat ca");
    playBeep(500, 100);
    return;
  }
  if (stopTarget == "media") {
    stopMediaOnly();
    currentState = STATE_IDLE;
    setSubtitle(oled.length() ? oled : "Da tat nhac/truyen");
    playBeep(500, 100);
    return;
  }
  if (stopTarget == "pomodoro") {
    stopPomodoro(false);
    setSubtitle(oled.length() ? oled : "Da tat Pomodoro");
    playBeep(500, 100);
    return;
  }

  if (state == "POMODORO") {
    startPomodoro(workMin > 0 ? workMin : 25, breakMin >= 0 ? breakMin : 5, "Hoc tap");
    setSubtitle(oled.length() ? oled : ("Pomodoro " + String(workMin) + "p"));
    currentState = STATE_SPEAKING;
    postSpeechState = STATE_IDLE;
    speechEndTime = millis() + 1400;
    nextSyllableTime = millis();
    return;
  }

  if (state == "MUSIC") {
    pushTempMemory("Da phat: " + oled);
    setSubtitle(oled);
    String lowerOled = oled;
    lowerOled.toLowerCase();
    if (lowerOled.indexOf("chill") >= 0 || lowerOled.indexOf("lofi") >= 0 || lowerOled.indexOf("buon") >= 0) {
      startMelody(MELODY_CHILL, sizeof(MELODY_CHILL) / sizeof(NoteStep), true);
    } else {
      startMelody(MELODY_UPBEAT, sizeof(MELODY_UPBEAT) / sizeof(NoteStep), true);
    }
    currentState = STATE_SPEAKING;
    postSpeechState = STATE_MUSIC;
    speechEndTime = millis() + 1500;
    nextSyllableTime = millis();
    return;
  }

  if (state == "STORY") {
    pushTempMemory("Da phat: " + oled);
    setSubtitle(oled);
    int sm = sleepMin > 0 ? sleepMin : 45;
    storySleepEndMs = millis() + (unsigned long)sm * 60000UL;
    startMelody(MELODY_STORY, sizeof(MELODY_STORY) / sizeof(NoteStep), true);
    currentState = STATE_SPEAKING;
    postSpeechState = STATE_STORY;
    speechEndTime = millis() + 1500;
    nextSyllableTime = millis();
    return;
  }

  setSubtitle(oled.length() ? oled : reply);
  currentState = STATE_SPEAKING;
  postSpeechState = STATE_IDLE;
  speechEndTime = millis() + 2000;
  nextSyllableTime = millis();
}

void runOfflineFallback(const String& cmd) {
  String lower = cmd;
  lower.toLowerCase();

  if (lower.indexOf("tat") >= 0 || lower.indexOf("dung") >= 0 || lower.indexOf("stop") >= 0) {
    String target = (lower.indexOf("pomodoro") >= 0) ? "pomodoro" : ((lower.indexOf("nhac") >= 0 || lower.indexOf("truyen") >= 0) ? "media" : "all");
    applyBotResult("IDLE", "Da dung hoat dong", "Da dung hoat dong (Offline).", 0, 0, 0, target);
  } else if (lower.indexOf("pomodoro") >= 0 || lower.indexOf("hen gio") >= 0) {
    int w = 25;
    int b = 5;
    if (lower.indexOf("1 phut") >= 0 || lower.indexOf("1p") >= 0) {
      w = 1;
      b = 1;
    }
    applyBotResult("POMODORO", "Pomodoro " + String(w) + "p/" + String(b) + "p", "Da bat Pomodoro " + String(w) + " phut, nghi " + String(b) + " phut.", w, b, 0, "");
  } else if (lower.indexOf("thoi tiet") >= 0 || lower.indexOf("weather") >= 0) {
    applyBotResult("SPEAKING", "Ha Noi 26C, it may (Offline)", "Che do Offline: Chua ket noi Worker. Deploy /api/esp de xem thoi tiet that.", 0, 0, 0, "");
  } else if (lower.indexOf("tin tuc") >= 0 || lower.indexOf("news") >= 0) {
    applyBotResult("SPEAKING", "VnExpress RSS (Offline)", "Che do Offline: Deploy /api/esp len Cloudflare de doc tin VnExpress that.", 0, 0, 0, "");
  } else if (lower.indexOf("wiki") >= 0 || lower.indexOf("la gi") >= 0 || lower.indexOf("newton") >= 0) {
    applyBotResult("SPEAKING", "Wiki: 3 dinh luat Newton", "Offline: 3 dinh luat chuyen dong Newton mo ta moi quan he giua luc va chuyen dong.", 0, 0, 0, "");
  } else if (lower.indexOf("truyen") >= 0 || lower.indexOf("ke") >= 0 || lower.indexOf("sach noi") >= 0) {
    applyBotResult("STORY", "Truyen ma Nguyen Ngoc Ngan", "Offline: Mo phong truyen audio (hen tat 45 phut).", 0, 0, 45, "");
  } else if (lower.indexOf("nhac") >= 0 || lower.indexOf("chill") >= 0 || lower.indexOf("lofi") >= 0 || lower.indexOf("music") >= 0 || lower.indexOf("origami") >= 0) {
    applyBotResult("MUSIC", "Nhac: Lofi Chill Study", "Offline: Phat giai dieu mo phong tren buzzer.", 0, 0, 0, "");
  } else {
    applyBotResult("SPEAKING", "AI mini ESP32-C3 Offline", "Xin chao! Hay bat Real Internet tren Mokxi va deploy /api/esp len Worker.", 0, 0, 0, "");
  }
}

void processSimCommand(const String& cmd) {
  String cleanCmd = cmd;
  cleanCmd.trim();
  if (cleanCmd.length() == 0) return;

  String lower = cleanCmd;
  lower.toLowerCase();

  Serial.print("[Ban noi]: ");
  Serial.println(cleanCmd);

  if (lower.startsWith("nho ") || lower.startsWith("ghi nho ")) {
    pushTempMemory(cleanCmd);
    setSubtitle("Da nho tam!");
    playBeep(880, 90);
    return;
  }
  if (lower == "xoa nho" || lower == "clear mem") {
    clearTempMemory();
    setSubtitle("Da xoa bo nho tam");
    playBeep(520, 90);
    return;
  }
  if (lower == "xem nho" || lower == "bo nho") {
    pruneMemory();
    Serial.printf("[Nho tam]: Co %u muc:\n", (unsigned)tempMemCount);
    for (size_t i = 0; i < tempMemCount; i++) {
      Serial.printf("  %u. %s\n", (unsigned)(i + 1), tempMem[i].text.c_str());
    }
    setSubtitle("Bo nho: " + String(tempMemCount) + " muc");
    return;
  }
  if (lower == "ngu" || lower == "sleep") {
    stopMediaOnly();
    currentState = STATE_SLEEPING;
    digitalWrite(LED_STATUS_PIN, LOW);
    drawCuteFace();
    return;
  }

  stopMediaOnly();
  currentState = STATE_THINKING;
  setSubtitle("Dang hoi Cloudflare...");
  drawCuteFace();

  wifiOnline = (WiFi.status() == WL_CONNECTED);
  if (wifiOnline) {
    HTTPClient http;
    String url = String(WORKER_ESP_URL) + "?q=" + urlEncode(cleanCmd);
    http.setTimeout(6500);
    if (http.begin(url)) {
      int code = http.GET();
      if (code == 200) {
        String body = http.getString();
        http.end();
        if (body.startsWith("STATE:")) {
          String st = getFieldLine(body, "STATE:");
          int workMin = getFieldLine(body, "WORK:").toInt();
          int breakMin = getFieldLine(body, "BREAK:").toInt();
          int sleepMin = getFieldLine(body, "SLEEP:").toInt();
          String stopTarget = getFieldLine(body, "STOP:");
          String oled = getFieldLine(body, "OLED:");
          String reply = getFieldLine(body, "REPLY:");
          applyBotResult(st, oled, reply, workMin, breakMin, sleepMin, stopTarget);
          return;
        }
        Serial.println("[Cloudflare]: Worker chua co route /api/esp -> dung Offline Fallback.");
      } else {
        Serial.printf("[Cloudflare]: HTTP loi %d -> dung Offline Fallback.\n", code);
        http.end();
      }
    }
  } else {
    Serial.println("[WiFi]: Chua ket noi Wokwi-GUEST -> dung Offline Fallback.");
  }

  runOfflineFallback(cleanCmd);
}

void triggerQuickVoiceDemo() {
  const char* demos[] = {
    "Thoi tiet Ha Noi",
    "Tin tuc cong nghe",
    "Dinh luat Newton la gi",
    "Pomodoro 1 phut nghi 1 phut",
    "Bat nhac Origami The Rare Occasions",
    "Ke truyen ma Nguyen Ngoc Ngan",
    "Tat het"
  };
  processSimCommand(demos[demoCycleIndex]);
  demoCycleIndex = (demoCycleIndex + 1) % 7;
}

void connectSimWiFi() {
  if (oledReady) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 16);
    display.println("AI MINI ESP32-C3");
    display.setCursor(14, 34);
    display.println("Ket noi WiFi...");
    display.display();
  }
  WiFi.mode(WIFI_STA);
  WiFi.begin(SIM_WIFI_SSID, SIM_WIFI_PASS);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 4500) {
    delay(150);
  }
  wifiOnline = (WiFi.status() == WL_CONNECTED);
  if (wifiOnline) {
    Serial.print("[WiFi]: Da ket noi Wokwi-GUEST! IP = ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("[WiFi]: Offline (khong co Wokwi-GUEST). Chay che do mo phong noi bo.");
  }
}

void playStartupEffect() {
  if (oledReady) {
    display.ssd1306_command(SSD1306_DISPLAYON);
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(16, 16);
    display.println("AI MINI ESP32-C3");
    display.setCursor(14, 34);
    display.println(wifiOnline ? "Cloudflare Online" : "Offline Simulator");
    display.display();
  }

  tone(SPEAKER_PIN, 523, 90);
  delay(110);
  tone(SPEAKER_PIN, 659, 90);
  delay(110);
  tone(SPEAKER_PIN, 784, 140);
  delay(160);
  noTone(SPEAKER_PIN);

  digitalWrite(LED_STATUS_PIN, HIGH);
  currentState = STATE_IDLE;
  setSubtitle(wifiOnline ? "Online! Go lenh / Nut5" : "Offline! Go lenh/Nut5");
  drawCuteFace();
}

#else

void startCaptivePortal() {
  portalActive = true;
  wifiOnline = false;
  WiFi.disconnect(true);
  WiFi.mode(WIFI_AP);
  WiFi.softAP("AI-Mini-Setup");
  dnsServer.start(53, "*", WiFi.softAPIP());

  portalServer.on("/", HTTP_GET, []() {
    String html = "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>AI Mini WiFi</title></head>"
                  "<body style='font-family:sans-serif;max-width:360px;margin:24px auto;padding:12px'>"
                  "<h3>Cau hinh WiFi AI Mini</h3>"
                  "<form method='POST' action='/save'>"
                  "<p>Ten WiFi (SSID):<br><input name='s' required style='width:100%;padding:8px'></p>"
                  "<p>Mat khau:<br><input name='p' type='password' style='width:100%;padding:8px'></p>"
                  "<button type='submit' style='padding:10px 18px'>Luu & Khoi dong lai</button>"
                  "</form></body></html>";
    portalServer.send(200, "text/html", html);
  });

  portalServer.on("/save", HTTP_POST, []() {
    String ssid = portalServer.arg("s");
    String pass = portalServer.arg("p");
    prefs.begin("aimini", false);
    prefs.putString("ssid", ssid);
    prefs.putString("pass", pass);
    prefs.end();
    portalServer.send(200, "text/html", "<h3>Da luu WiFi! Dang khoi dong lai...</h3>");
    delay(800);
    ESP.restart();
  });

  portalServer.onNotFound([]() {
    portalServer.sendHeader("Location", "http://192.168.4.1/", true);
    portalServer.send(302, "text/plain", "");
  });

  portalServer.begin();
  setSubtitle("AP: AI-Mini-Setup");
  Serial.println("[Portal]: Ket noi WiFi 'AI-Mini-Setup' roi mo http://192.168.4.1");
}

void onWebSocketEvent(WStype_t type, uint8_t* payload, size_t length) {
  if (type == WStype_CONNECTED) {
    wsConnected = true;
    currentState = STATE_IDLE;
    setSubtitle("Online! Giu GPIO9 noi");
    digitalWrite(LED_STATUS_PIN, HIGH);
    Serial.println("[WS]: Da ket noi Cloudflare Worker!");
  } else if (type == WStype_DISCONNECTED) {
    wsConnected = false;
    currentState = STATE_IDLE;
    setSubtitle("Mat ket noi WS...");
    Serial.println("[WS]: Ngat ket noi, dang tu dong ket noi lai...");
  } else if (type == WStype_BIN) {
    if (!isHoldingPTT && length >= 2) {
      currentState = STATE_SPEAKING;
      lastBotAudioMs = millis();
      int16_t* s = (int16_t*)payload;
      size_t count = length / 2;
      long acc = 0;
      for (size_t i = 0; i < count; i += 8) acc += abs(s[i]);
      audioLevel = constrain((int)(acc / max((size_t)1, count / 8) / 80), 15, 100);
      i2sWriteAudio(payload, length - (length % 2));
    }
  } else if (type == WStype_TEXT) {
    String msg((char*)payload, length);
    if (msg.startsWith("LOG:")) {
      Serial.println(msg);
      return;
    }
    String cmdType = extractJsonStr(msg, "type");
    if (cmdType == "INTERRUPT_AUDIO") {
      stopMediaOnly();
      if (!isHoldingPTT) currentState = STATE_IDLE;
    } else if (cmdType == "POMODORO") {
      String act = extractJsonStr(msg, "action");
      if (act == "stop") {
        stopPomodoro(false);
        setSubtitle("Da tat Pomodoro");
      } else {
        int wm = extractJsonInt(msg, "workMinutes", 25);
        int bm = extractJsonInt(msg, "breakMinutes", 5);
        String lbl = extractJsonStr(msg, "label");
        startPomodoro(wm, bm, lbl);
        setSubtitle("Pomodoro " + String(wm) + "p/" + String(bm) + "p");
      }
    } else if (cmdType == "PLAY_YOUTUBE") {
      String title = extractJsonStr(msg, "title");
      String vid = extractJsonStr(msg, "videoId");
      String mode = extractJsonStr(msg, "mode");
      setSubtitle((mode == "story" ? "Truyen: " : "Nhac: ") + title);
      Serial.printf("[YouTube]: %s (https://youtu.be/%s) - Luu y: ESP32 khong tu phat IFrame YouTube.\n", title.c_str(), vid.c_str());
    } else if (cmdType == "STOP_MEDIA") {
      String target = extractJsonStr(msg, "target");
      if (target == "all" || target == "media") stopMediaOnly();
      if (target == "all" || target == "pomodoro") stopPomodoro(false);
      currentState = STATE_IDLE;
      setSubtitle("Da dung phat");
    }
  }
}

void connectRealHardwareWiFi() {
  bool forcePortal = false;
  if (digitalRead(BTN_PTT_PIN) == LOW) {
    unsigned long t0 = millis();
    while (digitalRead(BTN_PTT_PIN) == LOW) {
      if (millis() - t0 >= 2500) {
        forcePortal = true;
        break;
      }
      delay(20);
    }
  }

  prefs.begin("aimini", true);
  String ssid = prefs.getString("ssid", "");
  String pass = prefs.getString("pass", "");
  prefs.end();

  if (forcePortal || ssid.length() == 0) {
    startCaptivePortal();
    return;
  }

  setSubtitle("Ket noi " + ssid);
  drawCuteFace();
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), pass.c_str());
  unsigned long t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) {
    delay(200);
  }
  if (WiFi.status() != WL_CONNECTED) {
    startCaptivePortal();
    return;
  }

  wifiOnline = true;
  Serial.print("[WiFi]: Da ket noi! IP = ");
  Serial.println(WiFi.localIP());

  switchI2SMode(I2S_MODE_SPK);
  playChime();

  webSocket.beginSSL(WORKER_HOST, 443, "/");
  webSocket.onEvent(onWebSocketEvent);
  webSocket.setReconnectInterval(3000);
  currentState = STATE_IDLE;
  setSubtitle("Dang noi Cloudflare...");
}

#endif

void setup() {
  Serial.begin(115200);
  delay(150);

  pinMode(BTN_PTT_PIN, INPUT_PULLUP);
  pinMode(LED_STATUS_PIN, OUTPUT);
  digitalWrite(LED_STATUS_PIN, LOW);

#if REAL_HARDWARE_MODE == 0
  pinMode(BTN_PWR_PIN, INPUT_PULLUP);
  pinMode(BTN_VOICE_PIN, INPUT_PULLUP);
  pinMode(SW_MAIN_PWR_PIN, INPUT_PULLUP);
  pinMode(MIC_ANALOG_PIN, INPUT);
  pinMode(SPEAKER_PIN, OUTPUT);
#else
  memset(silencePcm, 0, sizeof(silencePcm));
#endif

  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
  Wire.setClock(400000);
  oledReady = display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (!oledReady) {
    Serial.println("[OLED]: Khong tim thay SSD1306 tai 0x3C!");
  }

#if REAL_HARDWARE_MODE == 0
  Serial.println("==================================================");
  Serial.println("  AI MINI ESP32-C3 (MOKXI CLOUDFLARE EDITION)     ");
  Serial.println("  - Nut XANH LA (GPIO9): Giu de noi / Bam de ngat ");
  Serial.println("  - Nut XANH DUONG (GPIO5): Test 7 tinh nang that ");
  Serial.println("  - Nut DO (GPIO3): Ngu / Thuc (Sleep / Wake)     ");
  Serial.println("  - Cong tac GAT (GPIO6): Nguon cung ON/OFF       ");
  Serial.println("  - Go lenh vao 'Send to the board':              ");
  Serial.println("    'thoi tiet Ha Noi', 'tin tuc cong nghe',      ");
  Serial.println("    'dinh luat Newton la gi', 'pomodoro 1 phut',  ");
  Serial.println("    'bat nhac Origami', 'ke truyen ma', 'tat het' ");
  Serial.println("==================================================");

  if (digitalRead(SW_MAIN_PWR_PIN) == LOW) {
    currentState = STATE_POWER_OFF;
    if (oledReady) {
      display.clearDisplay();
      display.display();
      display.ssd1306_command(SSD1306_DISPLAYOFF);
    }
  } else {
    connectSimWiFi();
    playStartupEffect();
  }
#else
  Serial.println("==================================================");
  Serial.println("  AI MINI ESP32-C3 REAL HARDWARE (INMP441+MAX98)  ");
  Serial.println("  - Giu GPIO9 >2.5s khi bat nguon de doi WiFi     ");
  Serial.println("  - Giu GPIO9 de noi truc tiep voi Gemini Live    ");
  Serial.println("==================================================");
  connectRealHardwareWiFi();
#endif
}

void loop() {
  unsigned long now = millis();

#if REAL_HARDWARE_MODE == 0
  bool mainSwitchOn = (digitalRead(SW_MAIN_PWR_PIN) == HIGH);
  if (!mainSwitchOn) {
    if (currentState != STATE_POWER_OFF) {
      stopMediaOnly();
      stopPomodoro(true);
      currentState = STATE_POWER_OFF;
      digitalWrite(LED_STATUS_PIN, LOW);
      if (oledReady) {
        display.clearDisplay();
        display.display();
        display.ssd1306_command(SSD1306_DISPLAYOFF);
      }
      Serial.println("[Nguon cung]: OFF");
    }
    delay(30);
    return;
  } else if (currentState == STATE_POWER_OFF) {
    Serial.println("[Nguon cung]: ON");
    if (WiFi.status() != WL_CONNECTED) connectSimWiFi();
    playStartupEffect();
  }

  bool pwrDown = (digitalRead(BTN_PWR_PIN) == LOW);
  if (pwrDown && !lastPwrDown && (now - lastPwrEdgeMs > 60)) {
    lastPwrEdgeMs = now;
    if (currentState == STATE_SLEEPING) {
      Serial.println("[Nguon mem]: Thuc day!");
      playStartupEffect();
    } else {
      Serial.println("[Nguon mem]: Che do Ngu (Sleep)");
      stopMediaOnly();
      tone(SPEAKER_PIN, 440, 100);
      delay(120);
      tone(SPEAKER_PIN, 330, 150);
      delay(160);
      noTone(SPEAKER_PIN);
      digitalWrite(LED_STATUS_PIN, LOW);
      currentState = STATE_SLEEPING;
      drawCuteFace();
    }
  }
  lastPwrDown = pwrDown;

  updatePomodoro();
  updateStorySleepTimer();

  if (currentState == STATE_SLEEPING) {
    delay(30);
    return;
  }

  bool pttDown = (digitalRead(BTN_PTT_PIN) == LOW);
  if (pttDown) {
    if (!isHoldingPTT) {
      isHoldingPTT = true;
      pttStartTime = now;
      stopMediaOnly();
      tone(SPEAKER_PIN, 880, 65);
      digitalWrite(LED_STATUS_PIN, HIGH);
      currentState = STATE_LISTENING;
      setSubtitle("Dang nghe... (Go Serial)");
      drawCuteFace();
      Serial.println("[PTT]: Dang thu am (Mo phong bang bien tro GPIO4)...");
    }
    int rawMic = analogRead(MIC_ANALOG_PIN);
    int baseLevel = map(rawMic, 0, 4095, 12, 88);
    audioLevel = constrain(baseLevel + (int)random(-10, 12), 8, 100);
  } else if (isHoldingPTT) {
    isHoldingPTT = false;
    unsigned long heldMs = now - pttStartTime;
    if (heldMs < 320) {
      stopMediaOnly();
      currentState = STATE_IDLE;
      setSubtitle("Da ngat phat!");
      tone(SPEAKER_PIN, 520, 60);
      Serial.println("[PTT]: Bam nhanh -> Ngat ngay lap tuc.");
    } else {
      tone(SPEAKER_PIN, 660, 65);
      Serial.println("[PTT]: Mokxi khong co mic that -> tu goi demo tiep theo (hoac go lenh vao Serial).");
      triggerQuickVoiceDemo();
    }
  }

  bool voiceDown = (digitalRead(BTN_VOICE_PIN) == LOW);
  if (voiceDown && !lastVoiceDown && !isHoldingPTT && (now - lastVoiceEdgeMs > 60)) {
    lastVoiceEdgeMs = now;
    triggerQuickVoiceDemo();
  }
  lastVoiceDown = voiceDown;

  if (Serial.available() > 0) {
    String typed = Serial.readStringUntil('\n');
    typed.trim();
    if (typed.length() > 0) {
      processSimCommand(typed);
    }
  }

  updateSimAudioEngine();

#else

  if (portalActive) {
    dnsServer.processNextRequest();
    portalServer.handleClient();
    if (now - lastFrameTime >= 250) {
      lastFrameTime = now;
      drawCuteFace();
    }
    return;
  }

  wifiOnline = (WiFi.status() == WL_CONNECTED);
  webSocket.loop();
  updatePomodoro();
  updateStorySleepTimer();

  bool pttDown = (digitalRead(BTN_PTT_PIN) == LOW);
  if (pttDown) {
    if (!isHoldingPTT) {
      isHoldingPTT = true;
      pttStartTime = now;
      stopMediaOnly();
      switchI2SMode(I2S_MODE_MIC);
      currentState = STATE_LISTENING;
      setSubtitle("Dang thu mic INMP441...");
      drawCuteFace();
    }

    size_t bytesRead = 0;
#if USE_I2S_V3
    if (rxHandle != NULL) {
      i2s_channel_read(rxHandle, micRaw32, sizeof(micRaw32), &bytesRead, pdMS_TO_TICKS(30));
    }
#else
    i2s_read(I2S_NUM_0, micRaw32, sizeof(micRaw32), &bytesRead, pdMS_TO_TICKS(30));
#endif
    size_t samples = bytesRead / sizeof(int32_t);
    if (samples > 0) {
      long acc = 0;
      for (size_t i = 0; i < samples; i++) {
        int32_t v = micRaw32[i] >> 14;
        if (v > 32767) v = 32767;
        if (v < -32768) v = -32768;
        micPcm16[i] = (int16_t)v;
        acc += abs(v);
      }
      audioLevel = constrain((int)(acc / (long)samples / 60), 8, 100);
      if (wsConnected) {
        webSocket.sendBIN((uint8_t*)micPcm16, samples * sizeof(int16_t));
      }
    }
  } else if (isHoldingPTT) {
    isHoldingPTT = false;
    unsigned long heldMs = now - pttStartTime;
    if (wsConnected && heldMs >= 250) {
      for (int i = 0; i < 5; i++) {
        webSocket.sendBIN((uint8_t*)silencePcm, sizeof(silencePcm));
      }
      currentState = STATE_THINKING;
      setSubtitle("Dang cho Gemini...");
    } else {
      currentState = STATE_IDLE;
      setSubtitle("Da ngat!");
    }
    switchI2SMode(I2S_MODE_SPK);
  }

  if (currentState == STATE_SPEAKING && (now - lastBotAudioMs > 700)) {
    currentState = STATE_IDLE;
    audioLevel = 0;
    setSubtitle(wsConnected ? "San sang! Giu GPIO9" : "Mat ket noi WS...");
  }

#endif

  if (now - lastFrameTime >= 80) {
    lastFrameTime = now;
    drawCuteFace();
  }
}
