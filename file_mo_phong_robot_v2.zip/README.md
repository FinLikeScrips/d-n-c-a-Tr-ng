# AI Mini ESP32-C3 (Mokxi & Real Hardware)

1. Che do Mokxi (`#define REAL_HARDWARE_MODE 0`, mac dinh):
   - Import file `file_mo_phong_robot_v2.zip` vao https://app.mokxi.com/.
   - Tu dong ket noi WiFi `Wokwi-GUEST` (bat Real Internet Mode tren Mokxi) va goi HTTPS that toi `https://mybot.phamquangtruong777.workers.dev/api/esp`.
   - Neu chua cap nhat `/api/esp` tren Worker hoac mat mang, tu dong chuyen sang che do Offline Fallback (khong bi treo).
   - Nut Xanh la (`GPIO 9`): Giu de noi / bam nhanh de ngat.
   - Nut Xanh duong (`GPIO 5`): Test nhanh 7 tinh nang (Thoi tiet, Tin tuc, Wikipedia, Pomodoro 1p, Nhac, Truyen, Tat het).
   - Nut Do (`GPIO 3`): Sleep / Wake.
   - Cong tac gat (`GPIO 6`): Nguon cung ON/OFF.

2. Che do Mach That ESP32-C3 (`#define REAL_HARDWARE_MODE 1`):
   - Doi `#define REAL_HARDWARE_MODE 1`, cai them thu vien `WebSockets` (Markus Sattler / Links2004) trong Arduino IDE.
   - So do chan sach khong dung GPIO: OLED (`SCL=0, SDA=1`), I2S (`BCLK=4, WS=5, MIC_SD=6, SPK_DIN=7`), LED (`8`), PTT (`9`).
   - Giu `GPIO 9` >2.5s luc bat nguon de mo WiFi Captive Portal `AI-Mini-Setup` (`192.168.4.1`).
