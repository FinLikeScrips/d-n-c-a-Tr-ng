# sketch

Exported from Mokxi as a Wokwi project. On wokwi.com, start a new project for the same board, then replace its diagram.json, sketch.ino and libraries.txt with these (or upload them with the file menu).
