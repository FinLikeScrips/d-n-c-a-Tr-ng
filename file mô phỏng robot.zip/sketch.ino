#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// =====================================================================
// CHE DO CHAY:
//   0 = Mo phong day du tren Mokxi / Wokwi (Man hinh + Mic + Loa + Full Nut)
//   1 = Nap mach ESP32-C3 that (WiFi Captive Portal + INMP441 + MAX98357A + Gemini Worker)
// =====================================================================
#define REAL_HARDWARE_MODE 0

#if REAL_HARDWARE_MODE == 1
  #include <WiFi.h>
  #include <WebServer.h>
  #include <DNSServer.h>
  #include <Preferences.h>
  #include <WebSocketsClient.h>
  #if ESP_ARDUINO_VERSION_MAJOR >= 3
    #include <driver/i2s_std.h>
  #else
    #include <driver/i2s.h>
  #endif
#endif

// ================= SO DO CHAN GPIO DAY DU (ESP32-C3) =================
#define OLED_SCL_PIN     0    // SCL man hinh OLED 0.96" I2C
#define OLED_SDA_PIN     1    // SDA man hinh OLED 0.96" I2C
#define BTN_PWR_PIN      3    // Nut DO: Bat / Tat nguon mem (Sleep / Wake)
#define MIC_ANALOG_PIN   4    // Mo phong: Cam bien Mic Analog | Mach that: I2S SCK/BCLK
#define BTN_VOICE_PIN    5    // Nut XANH DUONG: Goi nhanh Voice / Nhac | Mach that: I2S WS
#define SW_MAIN_PWR_PIN  6    // Cong tac GAT: Nguon cung ON/OFF | Mach that: I2S SD (INMP441)
#define I2S_DIN_OUT_PIN  7    // Mach that: I2S DIN (Loa MAX98357A)
#define LED_STATUS_PIN   8    // Den LED bao trang thai hoat dong
#define BTN_PTT_PIN      9    // Nut XANH LA: GIU DE NOI & DUNG MOI HOAT DONG NGAY LAP TUC
#define SPEAKER_PIN      10   // Loa phat giong robot, hieu ung & giai dieu nhac

// ================= CAU HINH MAN HINH =================
#define SCREEN_WIDTH     128
#define SCREEN_HEIGHT    64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ================= TRANG THAI BOT =================
enum BotState {
  STATE_POWER_OFF,
  STATE_BOOT,
  STATE_IDLE,
  STATE_LISTENING,
  STATE_THINKING,
  STATE_SPEAKING,
  STATE_MUSIC,
  STATE_STORY,
  STATE_SLEEPING
};

BotState currentState = STATE_BOOT;

// Cac nốt nhac (Hz) de phat giai dieu khong chan (non-blocking)
struct NoteStep {
  uint16_t freq;
  uint16_t durMs;
};

// Nhac Buon Chill (Am thu du duong)
const NoteStep MELODY_SAD[] = {
  {440, 380}, {523, 380}, {494, 450}, {392, 500},
  {349, 380}, {440, 380}, {392, 450}, {330, 650},
  {294, 380}, {349, 380}, {330, 450}, {262, 550},
  {330, 400}, {294, 400}, {220, 800}, {0, 300}
};

// Nhac Vui Tuoi Nang Dong
const NoteStep MELODY_HAPPY[] = {
  {523, 180}, {659, 180}, {784, 180}, {1046, 320},
  {784, 180}, {1046, 360}, {0, 120},
  {587, 180}, {698, 180}, {880, 180}, {1175, 320},
  {880, 180}, {1046, 400}, {0, 200}
};

// Am thanh ke chuyen dem khuya nhe nhang
const NoteStep MELODY_STORY[] = {
  {330, 500}, {392, 500}, {440, 700}, {0, 250},
  {392, 500}, {330, 500}, {294, 750}, {0, 350}
};

const NoteStep* activeMelody = NULL;
size_t activeMelodyLen = 0;
size_t activeMelodyIdx = 0;
bool activeMelodyLoop = false;
unsigned long noteEndTime = 0;

// Giong noi Robot (Speaking) khong chan nut bam
unsigned long speechEndTime = 0;
unsigned long nextSyllableTime = 0;
unsigned long thinkDoneTime = 0;
String pendingReplyText = "";
BotState postSpeechState = STATE_IDLE;

// Trang thai giao dien & cam bien
String subtitleText = "San sang! Giu GPIO9 de noi";
int audioLevel = 0;
int eyeOffsetX = 0;
int targetEyeX = 0;
bool isBlinking = false;
unsigned long nextBlinkTime = 2500;
unsigned long nextSaccadeTime = 1800;
unsigned long lastFrameTime = 0;

// Quan ly nut nhan
bool isHoldingPTT = false;
unsigned long pttStartTime = 0;
bool lastVoiceBtn = HIGH;
bool lastPwrBtn = HIGH;
uint8_t demoCycleIndex = 0;

// ================= DUNG NGAY LAP TUC MOI HOAT DONG =================
void stopAllActivitiesImmediately() {
  noTone(SPEAKER_PIN);
  activeMelody = NULL;
  activeMelodyLen = 0;
  activeMelodyIdx = 0;
  speechEndTime = 0;
  thinkDoneTime = 0;
  postSpeechState = STATE_IDLE;
  audioLevel = 0;
  digitalWrite(LED_STATUS_PIN, LOW);
}

// ================= BAT DAU PHAT GIAI DIEU (KHONG CHAN NUT) =================
void startMelody(const NoteStep* notes, size_t count, bool loopPlay) {
  activeMelody = notes;
  activeMelodyLen = count;
  activeMelodyIdx = 0;
  activeMelodyLoop = loopPlay;
  noteEndTime = 0;
}

void updateAudioEngine() {
  unsigned long now = millis();

  // 1. Xu ly trang thai Bot dang suy nghi -> chuyen sang tra loi
  if (currentState == STATE_THINKING && thinkDoneTime > 0 && now >= thinkDoneTime) {
    thinkDoneTime = 0;
    currentState = STATE_SPEAKING;
    subtitleText = pendingReplyText;
    speechEndTime = now + 2200;
    nextSyllableTime = now;
    Serial.print("[Bot AI]: ");
    Serial.println(pendingReplyText);
  }

  // 2. Xu ly giong noi Robot nhap nhay mieng + phat loa khi dang tra loi
  if (currentState == STATE_SPEAKING) {
    if (now >= speechEndTime) {
      noTone(SPEAKER_PIN);
      audioLevel = 0;
      digitalWrite(LED_STATUS_PIN, HIGH);
      if (postSpeechState == STATE_MUSIC) {
        currentState = STATE_MUSIC;
      } else if (postSpeechState == STATE_STORY) {
        currentState = STATE_STORY;
      } else {
        currentState = STATE_IDLE;
      }
      return;
    }

    if (now >= nextSyllableTime) {
      int f = random(420, 980);
      int dur = random(55, 115);
      tone(SPEAKER_PIN, f, dur);
      audioLevel = random(30, 100);
      digitalWrite(LED_STATUS_PIN, !digitalRead(LED_STATUS_PIN));
      nextSyllableTime = now + dur + random(25, 60);
    }
    return;
  }

  // 3. Xu ly phat Nhac / Truyen Audio chay ngam
  if ((currentState == STATE_MUSIC || currentState == STATE_STORY) && activeMelody != NULL) {
    if (now >= noteEndTime) {
      if (activeMelodyIdx >= activeMelodyLen) {
        if (activeMelodyLoop) {
          activeMelodyIdx = 0;
        } else {
          stopAllActivitiesImmediately();
          currentState = STATE_IDLE;
          subtitleText = "Da phat xong!";
          return;
        }
      }

      uint16_t f = activeMelody[activeMelodyIdx].freq;
      uint16_t d = activeMelody[activeMelodyIdx].durMs;
      activeMelodyIdx++;

      if (f > 0) {
        tone(SPEAKER_PIN, f, d - 30);
        audioLevel = map(constrain((int)f, 220, 1100), 220, 1100, 25, 95);
        digitalWrite(LED_STATUS_PIN, HIGH);
      } else {
        noTone(SPEAKER_PIN);
        audioLevel = 10;
        digitalWrite(LED_STATUS_PIN, LOW);
      }
      noteEndTime = now + d;
    }
  }
}

// ================= VE MAN HINH MAT ROBOT CUTE + PHU DE =================
void drawCuteFace() {
  display.clearDisplay();
  unsigned long now = millis();

  if (currentState == STATE_POWER_OFF) {
    display.display();
    return;
  }

  if (currentState == STATE_SLEEPING) {
    display.fillRoundRect(22, 24, 30, 4, 2, SSD1306_WHITE);
    display.fillRoundRect(76, 24, 30, 4, 2, SSD1306_WHITE);
    display.drawCircle(64, 40, 3, SSD1306_WHITE);
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(92, 6);
    display.print("Zzz");
    display.setCursor(14, 54);
    display.print("Bam nut DO de thuc");
    display.display();
    return;
  }

  // Hieu ung chop mat va liec mat tu nhien
  if (now > nextBlinkTime && !isBlinking) {
    isBlinking = true;
    nextBlinkTime = now + 120;
  } else if (now > nextBlinkTime && isBlinking) {
    isBlinking = false;
    nextBlinkTime = now + random(2600, 5200);
  }

  if ((currentState == STATE_IDLE || currentState == STATE_MUSIC) && now > nextSaccadeTime) {
    int r = random(0, 5);
    targetEyeX = (r == 0) ? -7 : (r == 1 ? 7 : 0);
    nextSaccadeTime = now + random(1500, 3500);
  } else if (currentState != STATE_IDLE && currentState != STATE_MUSIC) {
    targetEyeX = 0;
  }
  eyeOffsetX += (targetEyeX - eyeOffsetX) / 2;

  int leftX = 22 + eyeOffsetX;
  int rightX = 76 + eyeOffsetX;
  int eyeY = 6;

  // Ve Doi Mat Cute
  if (isBlinking) {
    display.fillRoundRect(leftX, eyeY + 11, 30, 4, 2, SSD1306_WHITE);
    display.fillRoundRect(rightX, eyeY + 11, 30, 4, 2, SSD1306_WHITE);
  } else if (currentState == STATE_SPEAKING || currentState == STATE_MUSIC) {
    // Mat cuoi hip cong (^ ^)
    display.fillRoundRect(leftX, eyeY + 3, 30, 18, 9, SSD1306_WHITE);
    display.fillRoundRect(leftX + 4, eyeY + 10, 22, 14, 7, SSD1306_BLACK);
    display.fillRoundRect(rightX, eyeY + 3, 30, 18, 9, SSD1306_WHITE);
    display.fillRoundRect(rightX + 4, eyeY + 10, 22, 14, 7, SSD1306_BLACK);
  } else if (currentState == STATE_LISTENING) {
    // Mat mo to cham chu + ma hong
    display.fillRoundRect(leftX - 2, eyeY - 1, 34, 26, 9, SSD1306_WHITE);
    display.fillRoundRect(rightX - 2, eyeY - 1, 34, 26, 9, SSD1306_WHITE);
    display.fillCircle(leftX + 10, eyeY + 7, 4, SSD1306_BLACK);
    display.fillCircle(rightX + 10, eyeY + 7, 4, SSD1306_BLACK);
    display.drawLine(6, 34, 12, 30, SSD1306_WHITE);
    display.drawLine(11, 35, 17, 31, SSD1306_WHITE);
    display.drawLine(111, 31, 117, 35, SSD1306_WHITE);
    display.drawLine(116, 30, 122, 34, SSD1306_WHITE);
  } else if (currentState == STATE_THINKING) {
    // Mat liec len suy nghi
    display.fillRoundRect(leftX, eyeY + 2, 30, 22, 8, SSD1306_WHITE);
    display.fillRoundRect(rightX, eyeY + 2, 30, 22, 8, SSD1306_WHITE);
    display.fillCircle(leftX + 19, eyeY + 6, 3, SSD1306_BLACK);
    display.fillCircle(rightX + 19, eyeY + 6, 3, SSD1306_BLACK);
  } else {
    // Mat long lanh binh thuong
    display.fillRoundRect(leftX, eyeY, 30, 24, 8, SSD1306_WHITE);
    display.fillRoundRect(rightX, eyeY, 30, 24, 8, SSD1306_WHITE);
    display.fillCircle(leftX + 9, eyeY + 7, 4, SSD1306_BLACK);
    display.fillCircle(rightX + 9, eyeY + 7, 4, SSD1306_BLACK);
    display.fillCircle(leftX + 20, eyeY + 16, 2, SSD1306_BLACK);
    display.fillCircle(rightX + 20, eyeY + 16, 2, SSD1306_BLACK);
  }

  // Bieu tuong not nhac bay khi phat nhac / truyen
  if (currentState == STATE_MUSIC || currentState == STATE_STORY) {
    int ny = 4 + ((now / 250) % 6);
    display.fillCircle(8, ny + 6, 2, SSD1306_WHITE);
    display.drawLine(10, ny + 6, 10, ny, SSD1306_WHITE);
    display.drawLine(10, ny, 14, ny + 2, SSD1306_WHITE);
  }

  // Ve Mieng / Song am
  if (currentState == STATE_LISTENING) {
    int barH = map(constrain(audioLevel, 5, 100), 5, 100, 3, 14);
    for (int i = -3; i <= 3; i++) {
      int h = max(2, barH - abs(i) * 2);
      display.fillRoundRect(62 + i * 7, 41 - h / 2, 4, h, 2, SSD1306_WHITE);
    }
  } else if (currentState == STATE_SPEAKING) {
    int mouthH = map(constrain(audioLevel, 0, 100), 0, 100, 3, 13);
    int mouthW = map(constrain(audioLevel, 0, 100), 0, 100, 12, 24);
    display.fillRoundRect(64 - mouthW / 2, 35, mouthW, mouthH, mouthH / 2, SSD1306_WHITE);
  } else if (currentState == STATE_MUSIC || currentState == STATE_STORY) {
    for (int i = -2; i <= 2; i++) {
      int h = random(3, 12);
      display.fillRect(62 + i * 8, 45 - h, 5, h, SSD1306_WHITE);
    }
  } else if (currentState == STATE_THINKING) {
    int phase = (now / 180) % 3;
    for (int i = 0; i < 3; i++) {
      display.fillCircle(54 + i * 10, (i == phase) ? 38 : 42, 2, SSD1306_WHITE);
    }
  } else {
    display.drawLine(58, 39, 62, 42, SSD1306_WHITE);
    display.drawLine(62, 42, 66, 42, SSD1306_WHITE);
    display.drawLine(66, 42, 70, 39, SSD1306_WHITE);
  }

  // Dong phu de trang thai phia duoi cung man hinh OLED
  display.drawLine(0, 51, 127, 51, SSD1306_WHITE);
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(2, 55);
  if (subtitleText.length() > 21) {
    int offset = (now / 220) % (subtitleText.length() - 18);
    display.print(subtitleText.substring(offset, offset + 21));
  } else {
    display.print(subtitleText);
  }

  display.display();
}

// ================= XU LY CAU LENH GIONG NOI TIENG VIET =================
void processVoiceCommand(String cmd) {
  String lower = cmd;
  lower.toLowerCase();
  stopAllActivitiesImmediately();

  Serial.print("[Ban noi]: ");
  Serial.println(cmd);

  currentState = STATE_THINKING;
  subtitleText = "Dang suy nghi...";
  thinkDoneTime = millis() + 650;

  if (lower.indexOf("vang") >= 0 || lower.indexOf("gold") >= 0) {
    pendingReplyText = "SJC: Mua 84.5 - Ban 86.5 tr/luong";
    postSpeechState = STATE_IDLE;
  } else if (lower.indexOf("buon") >= 0 || lower.indexOf("chill") >= 0) {
    pendingReplyText = "Dang phat: Nhac Buon Chill Lofi...";
    postSpeechState = STATE_MUSIC;
    startMelody(MELODY_SAD, sizeof(MELODY_SAD) / sizeof(NoteStep), true);
  } else if (lower.indexOf("nhac") >= 0 || lower.indexOf("vui") >= 0 || lower.indexOf("hat") >= 0) {
    pendingReplyText = "Dang phat: Nhac Vui Tuoi Nang Dong!";
    postSpeechState = STATE_MUSIC;
    startMelody(MELODY_HAPPY, sizeof(MELODY_HAPPY) / sizeof(NoteStep), true);
  } else if (lower.indexOf("truyen") >= 0 || lower.indexOf("ke") >= 0) {
    pendingReplyText = "Ke chuyen Audio (Hen tat 45p)...";
    postSpeechState = STATE_STORY;
    startMelody(MELODY_STORY, sizeof(MELODY_STORY) / sizeof(NoteStep), true);
  } else if (lower.indexOf("tat") >= 0 || lower.indexOf("dung") >= 0 || lower.indexOf("im") >= 0) {
    thinkDoneTime = 0;
    currentState = STATE_IDLE;
    subtitleText = "Da dung phat nhac/truyen!";
    tone(SPEAKER_PIN, 500, 100);
  } else if (lower.indexOf("ngu") >= 0) {
    thinkDoneTime = 0;
    currentState = STATE_SLEEPING;
    digitalWrite(LED_STATUS_PIN, LOW);
  } else {
    pendingReplyText = "Xin chao! Toi la Bot AI ESP32-C3!";
    postSpeechState = STATE_IDLE;
  }
}

void triggerQuickVoiceDemo() {
  const char* demos[] = {
    "Xin chao bot!",
    "Gia vang hom nay bao nhieu?",
    "Hom nay hoi buon, bat nhac chill di",
    "Bat nhac vui tuoi len nao",
    "Mo truyen audio dem khuya",
    "Tat nhac"
  };
  processVoiceCommand(demos[demoCycleIndex]);
  demoCycleIndex = (demoCycleIndex + 1) % 6;
}

void playStartupEffect() {
  display.ssd1306_command(SSD1306_DISPLAYON);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(14, 18);
  display.println("XIAOZHI AI BOT C3");
  display.setCursor(12, 36);
  display.println("Full Audio & Voice");
  display.display();

  tone(SPEAKER_PIN, 523, 100);
  delay(120);
  tone(SPEAKER_PIN, 659, 100);
  delay(120);
  tone(SPEAKER_PIN, 784, 160);
  delay(180);
  noTone(SPEAKER_PIN);

  digitalWrite(LED_STATUS_PIN, HIGH);
  currentState = STATE_IDLE;
  subtitleText = "San sang! Giu GPIO9 de noi";
  drawCuteFace();
}

void setup() {
  Serial.begin(115200);
  delay(150);

  pinMode(BTN_PTT_PIN, INPUT_PULLUP);
  pinMode(BTN_VOICE_PIN, INPUT_PULLUP);
  pinMode(BTN_PWR_PIN, INPUT_PULLUP);
  pinMode(SW_MAIN_PWR_PIN, INPUT_PULLUP);
  pinMode(MIC_ANALOG_PIN, INPUT);
  pinMode(SPEAKER_PIN, OUTPUT);
  pinMode(LED_STATUS_PIN, OUTPUT);

  Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);
  Wire.setClock(400000);
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);

  Serial.println("==================================================");
  Serial.println("  XIAOZHI ESP32-C3 FULL PROJECT DA KHOI DONG!     ");
  Serial.println("  - Nut XANH LA (GPIO9): Giu de noi / Ngat ngay   ");
  Serial.println("  - Nut XANH DUONG (GPIO5): Demo Voice / Nhac     ");
  Serial.println("  - Nut DO (GPIO3): Bat / Tat nguon mem (Sleep)   ");
  Serial.println("  - Cong tac GAT (GPIO6): Nguon cung ON/OFF       ");
  Serial.println("  - Num xoay MIC (GPIO4): Gia lap song giong noi  ");
  Serial.println("  - Go cau lenh vao o 'Send to the board' ben duoi");
  Serial.println("    VD: 'gia vang', 'nhac buon', 'ke chuyen'      ");
  Serial.println("==================================================");

  if (digitalRead(SW_MAIN_PWR_PIN) == LOW) {
    currentState = STATE_POWER_OFF;
    display.clearDisplay();
    display.display();
    display.ssd1306_command(SSD1306_DISPLAYOFF);
  } else {
    playStartupEffect();
  }
}

void loop() {
  unsigned long now = millis();

  // 1. KIEM TRA CONG TAC GAT NGUON CUNG (SW_MAIN_PWR_PIN - GPIO 6)
  bool mainSwitchOn = (digitalRead(SW_MAIN_PWR_PIN) == HIGH);
  if (!mainSwitchOn) {
    if (currentState != STATE_POWER_OFF) {
      stopAllActivitiesImmediately();
      currentState = STATE_POWER_OFF;
      display.clearDisplay();
      display.display();
      display.ssd1306_command(SSD1306_DISPLAYOFF);
      Serial.println("[Nguon cung]: OFF (Da ngat toan bo dien)");
    }
    delay(30);
    return;
  } else if (currentState == STATE_POWER_OFF) {
    Serial.println("[Nguon cung]: ON (Khoi dong lai he thong)");
    playStartupEffect();
  }

  // 2. KIEM TRA NUT NGUON MEM SLEEP / WAKE (BTN_PWR_PIN - GPIO 3)
  bool pwrDown = (digitalRead(BTN_PWR_PIN) == LOW);
  if (pwrDown && lastPwrBtn == HIGH) {
    delay(40);
    if (digitalRead(BTN_PWR_PIN) == LOW) {
      if (currentState == STATE_SLEEPING) {
        Serial.println("[Nguon mem]: Thuc day!");
        playStartupEffect();
      } else {
        Serial.println("[Nguon mem]: Chuyen sang che do Ngu (Sleep)...");
        stopAllActivitiesImmediately();
        tone(SPEAKER_PIN, 440, 120);
        delay(130);
        tone(SPEAKER_PIN, 330, 180);
        currentState = STATE_SLEEPING;
        drawCuteFace();
      }
    }
  }
  lastPwrBtn = pwrDown;

  if (currentState == STATE_SLEEPING) {
    delay(30);
    return;
  }

  // 3. NUT GIU DE NOI & DUNG MOI HOAT DONG NGAY LAP TUC (BTN_PTT_PIN - GPIO 9)
  bool pttDown = (digitalRead(BTN_PTT_PIN) == LOW);
  if (pttDown) {
    if (!isHoldingPTT) {
      isHoldingPTT = true;
      pttStartTime = now;

      // DUNG NGAY LAP TUC moi nhac, truyen, giong noi cu de nghe ban noi!
      stopAllActivitiesImmediately();
      tone(SPEAKER_PIN, 880, 70);
      digitalWrite(LED_STATUS_PIN, HIGH);
      currentState = STATE_LISTENING;
      subtitleText = "Dang nghe ban noi...";
      drawCuteFace();
      Serial.println("[PTT Interrupt]: Da dung moi hoat dong -> Dang thu am Mic!");
    }

    // Doc cuong do giong noi tu cam bien Mic Analog (GPIO 4) + dao dong tu nhien
    int rawMic = analogRead(MIC_ANALOG_PIN);
    int baseLevel = map(rawMic, 0, 4095, 15, 85);
    audioLevel = constrain(baseLevel + (int)random(-15, 20), 8, 100);
  } else if (isHoldingPTT) {
    isHoldingPTT = false;
    unsigned long heldMs = now - pttStartTime;

    if (heldMs < 320) {
      // Bam nha nhanh < 0.32s -> Chi ngat im lang ngay lap tuc
      stopAllActivitiesImmediately();
      currentState = STATE_IDLE;
      subtitleText = "Da ngat! San sang nghe...";
      tone(SPEAKER_PIN, 520, 60);
      digitalWrite(LED_STATUS_PIN, HIGH);
      Serial.println("[PTT]: Da ngat khan cap tat ca hoat dong.");
    } else {
      // Da giu noi xong -> Phan hoi bang giong noi AI
      tone(SPEAKER_PIN, 660, 70);
      currentState = STATE_THINKING;
      subtitleText = "Dang xu ly giong noi...";
      thinkDoneTime = now + 650;
      pendingReplyText = "Da nghe ro! Ban can bat nhac hay xem gia vang?";
      postSpeechState = STATE_IDLE;
    }
  }

  // 4. NUT XANH DUONG: RA LENH VOICE NHANH / DOI NHAC (BTN_VOICE_PIN - GPIO 5)
  bool voiceBtnDown = (digitalRead(BTN_VOICE_PIN) == LOW);
  if (voiceBtnDown && lastVoiceBtn == HIGH && !isHoldingPTT) {
    delay(40);
    if (digitalRead(BTN_VOICE_PIN) == LOW) {
      triggerQuickVoiceDemo();
    }
  }
  lastVoiceBtn = voiceBtnDown;

  // 5. NHAN CAU NOI TIENG VIET TRUC TIEP QUA SERIAL ('Send to the board')
  if (Serial.available() > 0) {
    String typedVoice = Serial.readStringUntil('\n');
    typedVoice.trim();
    if (typedVoice.length() > 0) {
      processVoiceCommand(typedVoice);
    }
  }

  // 6. CAP NHAT BO PHAT LOA & MAN HINH MAT CUTE
  updateAudioEngine();

  if (now - lastFrameTime >= 80) {
    lastFrameTime = now;
    drawCuteFace();
  }
}
